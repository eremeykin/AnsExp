/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ansexp;

import javax.swing.*;
import java.awt.*;
import org.jdesktop.swingx.treetable.DefaultTreeTableModel;
import javax.swing.tree.DefaultTreeCellRenderer;
import org.jdesktop.swingx.JXTreeTable;
import org.jdesktop.swingx.treetable.*;

import org.jdesktop.swingx.JXTreeTable;
import org.jdesktop.swingx.treetable.DefaultMutableTreeTableNode;
import org.jdesktop.swingx.treetable.DefaultTreeTableModel;

import java.awt.event.ActionEvent;
import org.netbeans.swing.outline.Outline;

/**
 *
 * @author eremeykin
 */
public class AnsExp {

    public static void main(String[] args) {
        
//        TreeTableNode node = new DefaultMutableTreeTableNode("my node");
//        TreeTableModel model = new DefaultTreeTableModel(node);
//        JXTreeTable treeTable = new JXTreeTable(model);
//        //DefaultTreeTableModel dttm = new DefaultTreeTableModel(null, null);
//        DefaultTreeCellRenderer dtcr = new DefaultTreeCellRenderer();
//        dtcr.setFont(new Font("Timies New Roman", 0, 18));
//        treeTable.setRowHeight(30);
//        treeTable.setTreeCellRenderer(dtcr);
//        treeTable.setFont(new Font("Times New Roman", 0, 18));
//
//        JFrame frame = new JFrame();
//        JScrollPane scrollPane = new JScrollPane(treeTable);
//        frame.add(scrollPane, BorderLayout.CENTER);
//        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        //frame.add(AnsExp.treeTable);
//        frame.setSize(1100, 250);
//        frame.setVisible(true);
    }

}
