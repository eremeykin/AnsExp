/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ansexp;

import java.io.File;
import java.io.IOException;
import javax.swing.JOptionPane;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import org.xml.sax.SAXException;

/**
 *
 * @author eremeykin
 */
public class XMLParser {

    private static XMLParser parser = new XMLParser();
    private File xmlFile;
    private Node result;
    private Document document;

    private XMLParser() {
        //xmlFile = null;
        result = new Node("Root");
    }

    public static XMLParser getInstance(File file) {
        parser.xmlFile = file;
        parser.document = parser.getDocument();

        return parser;
    }

    public void parseToResult(org.w3c.dom.Node xmlNode) throws NullPointerException {
        if (!xmlNode.hasChildNodes()) {
            return;
        }
        for (int i = 0; i < xmlNode.getChildNodes().getLength(); i++) {
            //parseToResult(xmlNode.getChildNodes().item(i),n.getChildren());
            System.out.println(xmlNode.getNodeName());
        }
    }

    private Document getDocument() {
        Document doc = null;
        try {
            DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
            f.setValidating(false);
            DocumentBuilder builder = f.newDocumentBuilder();
            doc = builder.parse(this.xmlFile);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Произошла ошибка при чтении XML файла."
                    + "Программа будет закрыта");
            JOptionPane.showMessageDialog(null, e);
            System.exit(-1);
        }
        return doc;
    }

    public void setFile(File xmlFile) {
    }

    public Node getResult() {
        this.parseToResult(document);
        return result;
    }
}
